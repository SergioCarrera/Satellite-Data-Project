testNOAA.grc records satellite data and saves it to a wav file.

To view when satellites are in range, use Gpredict. I used this with Windows 10.

To get an image from wav file, use WXtoImg. I used this with Windows 10.